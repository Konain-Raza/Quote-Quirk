<?php

/*
Plugin Name: Quote Quirk
Plugin URI: https://example.com/quote-quirk
Description: Unleash the magic of words
Version: 1.0
Author: Konain Raza
Author URI: https://konainraza.vercel.app
*/


if (!defined("ABSPATH")) {
    die("");
}

class QuoteQuirk {
    public function __construct() {
        add_filter('admin_footer_text', array($this, 'admin_footer'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('quote-quirk', array($this, 'display_quotes'));
    }
    
    public function admin_footer() {
        
        $linkedin_url = 'https://www.linkedin.com/in/konain-raza-'; // Replace with your LinkedIn URL
        $footer_text = '
            Made with <span id="love">❤️ </span> by <a href="' . $linkedin_url . '" target="_blank">Konain Raza</a>';
        return $footer_text;
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('my-plugin-style', plugins_url('css/styles.css', __FILE__));
        wp_enqueue_script( 'my-plugin-script', plugins_url('scripts/script.js', __FILE__));
    }
    
    public function add_admin_menu() {
        add_menu_page('Quote Quirk', 'Quote Quirk', 'manage_options', 'quote-quirk', array($this, 'admin_menu_page'), 'dashicons-format-quote');
    }

    public function admin_menu_page() {
        if (isset($_POST['quote_category'])) {
            $selected_category = sanitize_text_field($_POST['quote_category']);
            update_option('quote_category', $selected_category);
        }
    
        $current_category = get_option('quote_category', 'happiness');
        ?>
          <div id="main">
          <div class="wrapy">
        <h1>Quote Quirk Settings</h1>

        <div id="short-code">
            <h2>Shortcode: [quote-quirk]</h2>
          <button class="copy" onclick="navigator.clipboard.writeText('[quote-quirk]').then(() => console.log('Text copied to clipboard')).catch(err => console.error('Failed to copy text:', err))">

  <span data-text-end="Copied!" data-text-initial="Copy to clipboard" class="tooltip"></span>
  <span>
    <svg xml:space="preserve" style="enable-background:new 0 0 512 512" viewBox="0 0 6.35 6.35" y="0" x="0" height="20" width="20" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xmlns="http://www.w3.org/2000/svg" class="clipboard">
      <g>
        <path fill="currentColor" d="M2.43.265c-.3 0-.548.236-.573.53h-.328a.74.74 0 0 0-.735.734v3.822a.74.74 0 0 0 .735.734H4.82a.74.74 0 0 0 .735-.734V1.529a.74.74 0 0 0-.735-.735h-.328a.58.58 0 0 0-.573-.53zm0 .529h1.49c.032 0 .049.017.049.049v.431c0 .032-.017.049-.049.049H2.43c-.032 0-.05-.017-.05-.049V.843c0-.032.018-.05.05-.05zm-.901.53h.328c.026.292.274.528.573.528h1.49a.58.58 0 0 0 .573-.529h.328a.2.2 0 0 1 .206.206v3.822a.2.2 0 0 1-.206.205H1.53a.2.2 0 0 1-.206-.205V1.529a.2.2 0 0 1 .206-.206z"></path>
      </g>
    </svg>
    <svg xml:space="preserve" style="enable-background:new 0 0 512 512" viewBox="0 0 24 24" y="0" x="0" height="18" width="18" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xmlns="http://www.w3.org/2000/svg" class="checkmark">
      <g>
        <path data-original="#000000" fill="currentColor" d="M9.707 19.121a.997.997 0 0 1-1.414 0l-5.646-5.647a1.5 1.5 0 0 1 0-2.121l.707-.707a1.5 1.5 0 0 1 2.121 0L9 14.171l9.525-9.525a1.5 1.5 0 0 1 2.121 0l.707.707a1.5 1.5 0 0 1 0 2.121z"></path>
      </g>
    </svg>
  </span>
</button>
        </div>
        <h3>Select Category:</h3>
        <form method="post" action="">
            <select name="quote_category">
                <option value="age" <?php selected($current_category, 'age'); ?>>Age</option>
                <option value="alone" <?php selected($current_category, 'alone'); ?>>Alone</option>
                <option value="amazing" <?php selected($current_category, 'amazing'); ?>>Amazing</option>
                <option value="anger" <?php selected($current_category, 'anger'); ?>>Anger</option>
                <option value="architecture" <?php selected($current_category, 'architecture'); ?>>Architecture</option>
                <option value="art" <?php selected($current_category, 'art'); ?>>Art</option>
                <option value="attitude" <?php selected($current_category, 'attitude'); ?>>Attitude</option>
                <option value="beauty" <?php selected($current_category, 'beauty'); ?>>Beauty</option>
                <option value="best" <?php selected($current_category, 'best'); ?>>Best</option>
                <option value="birthday" <?php selected($current_category, 'birthday'); ?>>Birthday</option>
                <option value="business" <?php selected($current_category, 'business'); ?>>Business</option>
                <option value="car" <?php selected($current_category, 'car'); ?>>Car</option>
                <option value="change" <?php selected($current_category, 'change'); ?>>Change</option>
                <option value="communication" <?php selected($current_category, 'communication'); ?>>Communication</option>
                <option value="computers" <?php selected($current_category, 'computers'); ?>>Computers</option>
                <option value="cool" <?php selected($current_category, 'cool'); ?>>Cool</option>
                <option value="courage" <?php selected($current_category, 'courage'); ?>>Courage</option>
                <option value="dad" <?php selected($current_category, 'dad'); ?>>Dad</option>
                <option value="dating" <?php selected($current_category, 'dating'); ?>>Dating</option>
                <option value="death" <?php selected($current_category, 'death'); ?>>Death</option>
                <option value="design" <?php selected($current_category, 'design'); ?>>Design</option>
                <option value="dreams" <?php selected($current_category, 'dreams'); ?>>Dreams</option>
                <option value="education" <?php selected($current_category, 'education'); ?>>Education</option>
                <option value="environmental" <?php selected($current_category, 'environmental'); ?>>Environmental</option>
                <option value="equality" <?php selected($current_category, 'equality'); ?>>Equality</option>
                <option value="experience" <?php selected($current_category, 'experience'); ?>>Experience</option>
                <option value="failure" <?php selected($current_category, 'failure'); ?>>Failure</option>
                <option value="faith" <?php selected($current_category, 'faith'); ?>>Faith</option>
                <option value="family" <?php selected($current_category, 'family'); ?>>Family</option>
                <option value="famous" <?php selected($current_category, 'famous'); ?>>Famous</option>
                <option value="fear" <?php selected($current_category, 'fear'); ?>>Fear</option>
                <option value="fitness" <?php selected($current_category, 'fitness'); ?>>Fitness</option>
                <option value="food" <?php selected($current_category, 'food'); ?>>Food</option>
                <option value="forgiveness" <?php selected($current_category, 'forgiveness'); ?>>Forgiveness</option>
                <option value="freedom" <?php selected($current_category, 'freedom'); ?>>Freedom</option>
                <option value="friendship" <?php selected($current_category, 'friendship'); ?>>Friendship</option>
                <option value="funny" <?php selected($current_category, 'funny'); ?>>Funny</option>
                <option value="future" <?php selected($current_category, 'future'); ?>>Future</option>
                <option value="god" <?php selected($current_category, 'god'); ?>>God</option>
                <option value="good" <?php selected($current_category, 'good'); ?>>Good</option>
                <option value="government" <?php selected($current_category, 'government'); ?>>Government</option>
                <option value="graduation" <?php selected($current_category, 'graduation'); ?>>Graduation</option>
                <option value="great" <?php selected($current_category, 'great'); ?>>Great</option>
                <option value="happiness" <?php selected($current_category, 'happiness'); ?>>Happiness</option>
                <option value="health" <?php selected($current_category, 'health'); ?>>Health</option>
                <option value="history" <?php selected($current_category, 'history'); ?>>History</option>
                <option value="home" <?php selected($current_category, 'home'); ?>>Home</option>
                <option value="hope" <?php selected($current_category, 'hope'); ?>>Hope</option>
                <option value="humor" <?php selected($current_category, 'humor'); ?>>Humor</option>
                <option value="imagination" <?php selected($current_category, 'imagination'); ?>>Imagination</option>
                <option value="inspirational" <?php selected($current_category, 'inspirational'); ?>>Inspirational</option>
                <option value="intelligence" <?php selected($current_category, 'intelligence'); ?>>Intelligence</option>
                <option value="jealousy" <?php selected($current_category, 'jealousy'); ?>>Jealousy</option>
                <option value="knowledge" <?php selected($current_category, 'knowledge'); ?>>Knowledge</option>
                <option value="leadership" <?php selected($current_category, 'leadership'); ?>>Leadership</option>
                <option value="learning" <?php selected($current_category, 'learning'); ?>>Learning</option>
                <option value="legal" <?php selected($current_category, 'legal'); ?>>Legal</option>
                <option value="marriage" <?php selected($current_category, 'marriage'); ?>>Marriage</option>
                <option value="medical" <?php selected($current_category, 'medical'); ?>>Medical</option>
                <option value="men" <?php selected($current_category, 'men'); ?>>Men</option>
                <option value="mom" <?php selected($current_category, 'mom'); ?>>Mom</option>
                <option value="money" <?php selected($current_category, 'money'); ?>>Money</option>
                <option value="morning" <?php selected($current_category, 'morning'); ?>>Morning</option>
                <option value="movies" <?php selected($current_category, 'movies'); ?>>Movies</option>
                <option value="success" <?php selected($current_category, 'success'); ?>>Success</option>
            </select>
            <button class="btn">
    <svg height="24" width="24" fill="#FFFFFF" viewBox="0 0 24 24" data-name="Layer 1" id="Layer_1" class="sparkle">
        <path d="M10,21.236,6.755,14.745.264,11.5,6.755,8.255,10,1.764l3.245,6.491L19.736,11.5l-6.491,3.245ZM18,21l1.5,3L21,21l3-1.5L21,18l-1.5-3L18,18l-3,1.5ZM19.333,4.667,20.5,7l1.167-2.333L24,3.5,21.667,2.333,20.5,0,19.333,2.333,17,3.5Z"></path>
    </svg>

    <span class="text">Confirm</span>
</button>
        </form>
    </div>
          </div>
    <?php
    }
    


    public function display_quotes() {
        $quote_data = $this->get_quote();

        if ($quote_data && !empty($quote_data)) {
            print_r($quote_data);
            $quote = $quote_data[0]['quote'];
            $author = $quote_data[0]['author'];
        } else {
            $quote = "Unable to fetch quote.";
            $author = "";
        }

        return "
        <div class='quote-container'>
            <p class='quote'>\"$quote\"</p>
            <p class='author'>~ $author</p>
        </div>";
    }

    private function get_quote() {
        $category = get_option('quote_category', 'happiness'); 

        $url = "https://api.api-ninjas.com/v1/quotes?category={$category}";
        $response = wp_remote_get($url, array(
            'headers' => array(
                'X-Api-Key'=> '2MYEMyB6vzt7MZfwvuw59g==4zJsyAtjITt33eSI',
            )
        ));

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        return $data;
    }
}

new QuoteQuirk();