document.addEventListener("DOMContentLoaded", () => {
    let copybtn = document.querySelector(".copy");

    if (copybtn) {
        copybtn.addEventListener("click", (e) => {
            console.log(e);
        });
    }
    else{
        console.log("not")
    }
});